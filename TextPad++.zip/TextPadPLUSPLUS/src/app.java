import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;

public class app {
    public static void main(String[] args) {
        JFrame window = new JFrame("TextPad++");
        window.setSize(1000,750);
        window.setLayout(new BorderLayout());
        window.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JTextArea textArea = new JTextArea(5,20);
        JScrollPane scrollP = new JScrollPane(textArea);
        window.add(scrollP);
        window.setVisible(true);
    }
}
